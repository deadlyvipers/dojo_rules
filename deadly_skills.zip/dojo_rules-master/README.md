Dojo Rules
==========

This repository contains a list of dojo rules for the Deadly Vipers dojo

