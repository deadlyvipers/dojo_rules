Dojo Rules
==========
* Always be on time
* Always take off your shoes
* Keep the dojo tidy
* Never bring live blades on the tatami
* Respect your opponents
* Most Sensei's should be respected
